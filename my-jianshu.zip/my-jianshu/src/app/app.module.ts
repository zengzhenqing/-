import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { ArticleComponent }from'./article/article.component';
import { NavComponent }from'./nav/nav.component'
import { AppComponent } from './app.component';
import {AdvertisingComponent}from'./advertising/advertising.component';
import {LoginComponent}from'./login/login.component'
// import {RecommendComponent}from'./recommend/recommend.component'

@NgModule({
  declarations: [
    AppComponent,
    ArticleComponent,
    NavComponent,
    AdvertisingComponent,
    // LoginComponentn
    // RecommendComponent
  ],
  imports: [
    BrowserModule,
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
