/**
 * Created by zzq on 2018/1/11.
 */
import {Component,OnInit}from '@angular/core'

@Component({
  selector:'app-advertising',
  templateUrl:'advertising.component.html',
  styleUrls:['advertising.component.css']
})
export class AdvertisingComponent implements OnInit{
  constructor(){}
  ngOnInit(){}
}
